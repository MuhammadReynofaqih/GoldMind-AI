# GOLDMIND ANALYSIS FRAMEWORK

Every analysis must follow this exact order.

1.
Macro Analysis

↓

2.
Economic Events

↓

3.
DXY Analysis

↓

4.
Weekly Structure

↓

5.
Daily Structure

↓

6.
H4 Structure

↓

7.
H1 Bias

↓

8.
M15 Execution

↓

9.
Liquidity

↓

10.
BOS

↓

11.
CHOCH

↓

12.
Order Block

↓

13.
Fair Value Gap

↓

14.
Premium Discount

↓

15.
Volume

↓

16.
VWAP

↓

17.
EMA

↓

18.
RSI

↓

19.
MACD

↓

20.
ATR

↓

21.
Fibonacci

↓

22.
Session Timing

↓

23.
Risk Management

↓

24.
Trade Score

↓

25.
Decision

BUY

SELL

or

NO TRADE